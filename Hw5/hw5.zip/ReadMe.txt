ReadMe

每題python需要import libsvm
根據你的路徑
sys.path.append('路徑')

